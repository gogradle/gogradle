# Dependency Graph

# external/a#3

- external/b#4
- external/c#4

# external/b#3

no dependencies

# external/b#4

- external/d#1
- external/c#4

# external/c#3

- external/d#3
- external/e#1

# external/c#4

- external/d#4
- external/e#1

# external/d#1

no dependencies

# external/d#3

- external/e#2

# external/d#4

- external/e#2

# external/e#1

no dependencies

# external/e#2

no dependencies

# external/e#3

no dependencies

# firstlevel/a#1

no dependencies

# firstlevel/a#2

locked:

- vendorexternal/a#2
- vendorexternal/b#2
- external/e#3
- external/a#3

vendor:

- vendorexternal/a#1
- vendorexternal/b#2

# firstlevel/b#3 

vendor:

- vendoronly/a#2
  - vendoronly/c#2
    - vendoronly/b#1
  - vendoronly/d#2
    - vendoronly/b#3
- vendoronly/b#2
- vendoronly/e#2

# firstlevel/c#3

- external/a#3
- external/b#3
- external/c#4

# firstlevel/c#4

no dependencies

# firstlevel/d#2

transitive = false

- external/e#4

# firstlevel/e#5

depends on but exclude:

- external/e#5

# vendorexternal/a#1

no dependencies

# vendorexternal/a#2

no dependencies

# vendorexternal/b#2

no dependencies





