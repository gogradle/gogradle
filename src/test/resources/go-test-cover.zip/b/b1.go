package b 

func B1(b int) bool {
    if b == 1 {
         return true
    } else {
         return false
    }
}

