package a

func A1(a int) bool {
    if a == 1 {
         return true
    } else {
         return false
    }
}

