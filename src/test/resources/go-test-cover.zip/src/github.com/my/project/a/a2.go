package a

func A2(a int) bool {
    if a==2 {
        return true
    } else {
        return false
    }
}

func ThisIsAnUnusedFunction(){
}

